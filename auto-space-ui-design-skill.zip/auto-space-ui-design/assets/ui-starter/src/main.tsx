import { StrictMode } from "react"
import { createRoot } from "react-dom/client"

import App from "./App"
import AdminDashboard from "./AdminDashboard"
import "./styles.css"
import "./admin.css"

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    {location.pathname === "/library" ? <App /> : <AdminDashboard />}
  </StrictMode>,
)
